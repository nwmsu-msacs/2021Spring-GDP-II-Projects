import React from 'react';
import './Header.css';


const Header = () => (
  <div className="header fixed-top mx-0 py-3 text-center">
    <h3 className = "heading">Quest Hunt</h3> 
  {/* <div className="link-div">
    <a href="https://questhunt-backend.herokuapp.com/locations">View Locations </a>
  </div> */}
  </div>
    
)
export default Header;