export default [
    {status_message : "Your target location is Colden Pond."},
    {status1_message : "Sorry, You haven't reached the target location."}
]