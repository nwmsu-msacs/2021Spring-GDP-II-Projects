export default [
    {
        Name: 'Colden Hall',
        type: 'circle',
        coordinate: [
            {
            latitude: 40.35108979954159, 
            longitude: -94.88241248675814
        }
        ],

    },
    {
        Name: 'Horizons West Apartments',
        type: 'circle',
        coordinate: [
            {
                latitude: 41.31447748801441,
            longitude: -95.05660917970772
            }
        ]

    },
    {
        Name: 'B.D Owens Library',
        type: 'circle',
        coordinate: [
            {
            latitude: 40.353523,
            longitude: -94.886021
        }
    ]

    }
];