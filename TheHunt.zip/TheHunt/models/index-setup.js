
module.exports = async (sequelize) => {
    const Location = await sequelize.models;

};