
module.exports = {
     //BASE_URL: "http://localhost:3001/location/",
     BASE_URL: "https://treasure-locator-backend.herokuapp.com/location/"
} 