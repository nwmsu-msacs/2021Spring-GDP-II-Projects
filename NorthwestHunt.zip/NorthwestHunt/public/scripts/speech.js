export default [
    {
      status_message:
        "Congratulations, you have reached the location",
    },
    { status1_message: "Sorry, you are outside the target location" },
  ];