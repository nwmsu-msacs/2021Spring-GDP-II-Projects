export const response = [{
    colorComponent1: "Hello! Your treasure location is ready ",
    colorComponent2Success: "Congratulations!! You have reached Quest: ",
    colorComponent2failure: "You haven't reached the quest. Go on you can do this!!!!!!"
}];
