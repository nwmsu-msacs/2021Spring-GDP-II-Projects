export default [
    {
        name: 'UPD',
        type: 'quad',
        coordinates: [
            {
                latitude: 40.35606,
                longitude: -94.88205
            },
            {
                latitude: 40.35606,
                longitude: -94.88205
            },
            {
                latitude: 40.35606,
                longitude: -94.88205
            },
            {
                latitude: 40.35606,
                longitude: -94.88205
            }
        ]
    },
    
    {
        Name:'Colden Pond',
        Latitude:40.35007, 
        Longitude:-94.88305,
    },
{
    Name: "B.D Owens Library",
    Latitude: 40.35385,
    Longitude: -94.88591,
  },
 
    {
      name: "Colden pond",
      type: "quad",
      coordinates: [
        {
          latitude: 40.350432552740905, longitude: -94.88331533526484
        },
        { latitude: 40.35044243036788, longitude: -94.88263487819215 },
        { latitude: 40.3496522156376, longitude: -94.88254415058246 },
        { latitude: 40.34966209337887, longitude: -94.88328941309065 },
      ],
    },
    {
      Name: "B.D Owens Library",
      type: "quad",
      coordinates: [
        {
          latitude: 40.35379248029996, longitude: -94.88664157526523
        },
        { latitude: 40.35376625288228, longitude: -94.88542368602904 },
        { latitude: 40.3533346213619, longitude: -94.88557942049536 },
        { latitude: 40.35335914959811, longitude: -94.8864269985441 },
      ],
    },
    {
      Name: "Horizons west apartments",
      type: "quad",
      coordinates: [
        {
          latitude: 40.356209392187104, longitude: -94.88259215855203
        },
        { latitude: 40.35618844720869, longitude: -94.88130491448193 },
        { latitude: 40.3558044547846, longitude: -94.88131407636145 },
        { latitude: 40.3558044547846, longitude: -94.88261506325078 },
      ],
    },
    {
      Name: "Foster Fitness Center",
      type: "quad",
      coordinates: [
        {
          latitude: 40.35068640403606, longitude: -94.88442627293685
        },
        { latitude: 40.35066826969888, longitude: -94.88405347917049 },
        { latitude: 40.350251178598, longitude: -94.88393450243655 },
        { latitude: 40.350245133780476, longitude: -94.8844580000659 },
  
      ],
    },
  
    {
      Name: "Admin block",
      type: "quad",
      coordinates: [
        { latitude: 40.35326492425625, longitude: -94.88411981172477 },
        { latitude: 40.353672456736, longitude: -94.88321883322703 },
        { latitude: 40.35335020996101, longitude: -94.88295710723392 },
        { latitude: 40.352921960581384, longitude: -94.88391697132933 },
      ],
    },
    {
      Name: "Village O Apartments",
      type: "quad",
      coordinates: [
        {latitude:40.36132959481614,longitude: -94.88827429572812},
        {latitude:40.36109633521448, longitude:-94.88777978731646},
        {latitude: 40.36094281609458,longitude: -94.88790764725674},
        {latitude:40.36116914039704, longitude:-94.88840180749345},
       
      ],
    }
    
  ];
  


