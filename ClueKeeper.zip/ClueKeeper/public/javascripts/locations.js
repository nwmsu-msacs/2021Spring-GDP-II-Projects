export default [
    {
        name: '1213 Apartments',
        type: 'quad',
        coordinates: [
            {
                latitude: 40.360857,
                longitude: -94.888152
            },
            {
                latitude: 40.360849,
                longitude: -94.887489
            },
            {
                latitude: 40.360495,
                longitude: -94.887500
            },
            {
                latitude: 40.360521,
                longitude: -94.888210
            }            
        ]
    },
    
    {
        name: '5860 McCrimmon Parkway',
        type: 'quad',
        coordinates: [
            {
                Latitude: 35.8416, 
                Longitude: -78.852915
            },
            
            {
                Latitude: 35.8429, 
                Longitude: -78.853732
            },
            
            {
                Latitude: 35.8280, 
                Longitude: -78.855489                
            },
            
            {
                Latitude: 35.8216, 
                Longitude: -78.858790
            }
            
          ]
    },
            
            
            
    
    {
        name:'B.D Owens Library',
        type: 'quad',
        coordinates: [
            {
                Latitude: 35.8416,
                Longitude: -78.852915
            },

            {
                Latitude: 35.8429,
                Longitude: -78.853732
            },

            {
                Latitude: 35.8280,
                Longitude: -78.855489
            },

            {
                Latitude: 35.8216,
                Longitude: -78.858790
            }

        ]
    }

];
