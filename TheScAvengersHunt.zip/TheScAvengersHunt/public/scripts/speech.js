export default [
  {
    status_message:
      "Yahoo! Congratulations, you have reached the target location",
  },
  { status1_message: "Sorry, you are outside the target location" },
];
