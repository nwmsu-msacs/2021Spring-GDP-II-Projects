export default [
    {
        Name: 'Colden Pond',
        type: 'circle',
        coordinate:
        {
            latitude: 40.35112686830798,
            longitude: -94.88220243759864
        }

    },
    {
        Name: 'Horizons West Apartments',
        type: 'circle',
        coordinate: [
        {
            latitude: 41.31447748801441,
            longitude: -95.05660917970772
        }]


    },
    {
        Name: 'B.D Owens Library',
        type: 'circle',
        coordinate:[
        {
            latitude: 40.353523,
            longitude: -94.886021
        }]

    }
];
