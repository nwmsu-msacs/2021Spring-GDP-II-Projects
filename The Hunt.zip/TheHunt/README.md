# Group-1-Treasure [![Website shields.io](https://img.shields.io/website-up-down-green-red/http/shields.io.svg)](https://group-1-treasure.herokuapp.com/)
- A single page Web Application.
- The page displays two color boxs.
- When the user clicks on the first box, a coordinnate of the Quest will be set as the destination coordinates.
- As user  touches  the first color to request a treasure  location.
- When the user clicks on the scound box, distance is calculated between the current location of the user and choosen Quest coordinates.

# About GD: https://group-1-treasure.herokuapp.com/GD

# Stack for the Application:
- HTML.
- CSS.
- Bootstrap
- JavaScript.
- jQuery
- Node with Express.
- Mongodb.

# Heroku hosted link : 

  https://group-1-treasure.herokuapp.com/
  
 # create heroku hosted
 
 https://group-1-treasure.herokuapp.com/location/create?
 
#  display data 

https://group-1-treasure.herokuapp.com/location/display?
 
 
 # Github source link 
 
 https://github.com/GD-Prasad/Group-1-Treasure

# Team Members.
 <table>
<td align="center"><a href="https://github.com/GD-Prasad"><img src="https://avatars.githubusercontent.com/u/59986885?s=400&u=df8057f5d9aa0936da702cdb1a5a776ceddf12a5&v=4" width="100px;" alt=""/><br /><sub><b>GD Prasad</b></sub></a><br /></td>
<td align="center"><a href="https://github.com/Saikrishna1545"><img src="https://avatars.githubusercontent.com/u/60013018?s=460&u=4687be0646ecbb59bd281276c302eba966ff5f64&v=4" width="100px;" alt=""/><br /><sub><b>Sai Krishna Emmadishetty
</b></sub></a><br /></td>

</table>
