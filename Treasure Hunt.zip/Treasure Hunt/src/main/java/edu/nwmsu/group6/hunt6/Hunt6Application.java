package edu.nwmsu.group6.hunt6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hunt6Application {

	public static void main(String[] args) {
		SpringApplication.run(Hunt6Application.class, args);
	}

}
