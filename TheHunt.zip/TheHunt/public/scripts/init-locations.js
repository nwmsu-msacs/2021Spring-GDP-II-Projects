export default [
    {
        Name: 'Colden Pond',
        type: 'circle',
        coordinate: 
            {
            latitude: 40.3501358970608,
            longitude: -94.88300668346238
             
        }
        
        
    },
    {
        Name: 'Horizons West Apartments',
        type: 'circle',
        coordinate: [
            {
                latitude: 40.35613747319153,
            longitude: -94.88199841811789
            }
        ]

    },
    {
        Name: 'B.D Owens Library',
        type: 'circle',
        coordinate: [
            {
            latitude: 40.35379248029996,
            longitude: -94.88604076044588
        }
    ]

    }
];

